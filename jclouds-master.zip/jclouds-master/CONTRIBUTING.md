Please review the [How to Contribute](https://cwiki.apache.org/confluence/display/JCLOUDS/Contribute) page for information on how to submit your patch and how the review process works.

Also make sure all the changes are aligned with the [Coding Standards](https://cwiki.apache.org/confluence/display/JCLOUDS/Writing+jclouds+Code) of the project.

Thanks!

The Apache jclouds team
