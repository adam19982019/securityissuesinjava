#
# The jclouds API for EMC's Atmos Online Storage (http://www.emccis.com/).
#
# TODO: Implementation status.
# TODO: Supported features.
# TODO: Usage example.
