package rml.service;

public interface RepairServiceI {

	public void repair();

	public void deleteAndRepair();

}
