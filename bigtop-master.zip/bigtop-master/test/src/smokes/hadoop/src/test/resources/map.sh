#!/bin/bash
xargs cat
